function [x, y, vx, vy] = ball_step(x, y, vx, vy, dt, m, g)

x = 0; error('Udregn den opdaterede vaerdi for x vha lign. 6')
y = 0; error('Udregn den opdaterede vaerdi for y vha lign. 6')
vy = 0; error('Udregn den opdaterede vaerdi for vy vha lign. 6')

end
