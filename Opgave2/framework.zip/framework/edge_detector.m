function J = edge_detector(I)

[M, N] = size(I);
J = zeros( size(I) );

Ex = 0; error('Indsaet Sobel operator for Ex')
Ey = 0; error('Indsaet Sobel operator for Ey')

for i=2:M-1
  for j=2:N-1
    
    A = 0; error('Konstruer nabomatrix for pixel (i,j)')
    val1 = 0; error('Fold med Sobel operator for Ex')
    val2 = 0; error('Fold med Sobel operator for Ey')
    J(i,j) = 0; error('Udregn resultat')
    
  end
end

end